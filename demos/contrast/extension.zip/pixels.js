function enhancePixels(ctx, gain) {
  const frame = ctx.getImageData(0, 0, ctx.canvas.width, ctx.canvas.height);
  const { data } = frame;
  for (let i = 0; i < data.length; i += 4) {
    for (let c = 0; c < 3; c++) {
      data[i + c] =
        128 + (data[i + c] - 128) * gain;
    }
  }
  ctx.putImageData(frame, 0, 0);
}
