(() => {
  const selection = globalThis.imageContrastSelection ??= { originals: new WeakMap() };
  if (selection.cancel) {
    selection.cancel();
    return;
  }

  const hint = document.createElement('div');
  hint.setAttribute('role', 'status');
  hint.textContent = 'Выберите изображение. Esc — отмена.';
  hint.style.cssText = 'all:initial;position:fixed;top:12px;left:12px;z-index:2147483647;padding:10px 14px;border-radius:4px;background:#132342;color:#fff;font:16px system-ui;pointer-events:none';
  document.documentElement.append(hint);

  const listeners = new AbortController();
  selection.cancel = () => {
    listeners.abort();
    hint.remove();
    selection.cancel = null;
  };
  const options = { capture: true, signal: listeners.signal };

  function process(source) {
    const canvas = document.createElement('canvas');
    canvas.width = source.naturalWidth;
    canvas.height = source.naturalHeight;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(source, 0, 0);
    enhancePixels(ctx, 4);
    return canvas.toDataURL();
  }

  function restore(image, attributes) {
    for (const [element, name, value] of attributes) {
      if (value === null) element.removeAttribute(name);
      else element.setAttribute(name, value);
    }
    selection.originals.delete(image);
  }

  async function apply(image) {
    await image.decode();
    const originalURL = image.currentSrc;
    let enhanced;
    try {
      enhanced = process(image);
    } catch (error) {
      if (error.name !== 'SecurityError') throw error;
      const corsImage = new Image();
      corsImage.crossOrigin = 'anonymous';
      corsImage.src = originalURL;
      try {
        await corsImage.decode();
      } catch {
        throw new Error('Сервер изображения не разрешает чтение пикселей.');
      }
      enhanced = process(corsImage);
    }
    if (!image.isConnected || image.currentSrc !== originalURL) return;

    // Check CSP before altering the displayed image.
    const preview = new Image();
    preview.src = enhanced;
    try {
      await preview.decode();
    } catch {
      throw new Error('Политика страницы блокирует показ обработанного изображения.');
    }
    if (!image.isConnected || image.currentSrc !== originalURL) return;

    const sources = image.parentElement?.matches('picture')
      ? [...image.parentElement.querySelectorAll(':scope > source')]
      : [];
    const attributes = [[image, 'src', image.getAttribute('src')]];
    for (const element of [image, ...sources]) {
      attributes.push([element, 'srcset', element.getAttribute('srcset')]);
      element.removeAttribute('srcset');
    }
    selection.originals.set(image, attributes);
    image.src = enhanced;
  }

  window.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') selection.cancel();
  }, options);

  window.addEventListener('click', async (event) => {
    const image = event.composedPath().find((node) => node instanceof HTMLImageElement);
    if (!image) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    listeners.abort();
    if (selection.originals.has(image)) {
      restore(image, selection.originals.get(image));
      selection.cancel();
      return;
    }
    hint.textContent = 'Обрабатываем изображение…';
    const cancel = selection.cancel;
    try {
      await apply(image);
      cancel();
    } catch (error) {
      hint.textContent = error.message || 'Не удалось обработать изображение.';
      setTimeout(cancel, 3500);
    }
  }, options);
})();
