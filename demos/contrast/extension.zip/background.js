chrome.action.onClicked.addListener(async ({ id: tabId }) => {
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ['pixels.js', 'contrast.js'] });
  } catch {
    // Chrome forbids injection into privileged pages and the Chrome Web Store.
  }
});
